package com.recoleccion.recoleccionbasura.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class VistaController {

    @GetMapping("/login")
    public String login() {
        // src/main/resources/templates/login_frontend.html
        return "login_frontend";
    }

    @GetMapping("/admin")
    public String admin() {
        // src/main/resources/templates/admin.html
        return "admin";
    }

    @GetMapping("/chofer")
    public String chofer() {
        // src/main/resources/templates/chofer.html
        return "chofer";
    }
}

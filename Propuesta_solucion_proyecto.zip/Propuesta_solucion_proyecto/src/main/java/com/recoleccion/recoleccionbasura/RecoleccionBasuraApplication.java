package com.recoleccion.recoleccionbasura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecoleccionBasuraApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecoleccionBasuraApplication.class, args);
	}

}

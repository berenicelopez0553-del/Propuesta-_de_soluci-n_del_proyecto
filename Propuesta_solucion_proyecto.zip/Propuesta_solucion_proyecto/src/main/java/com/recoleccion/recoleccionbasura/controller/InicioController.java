package com.recoleccion.recoleccionbasura.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InicioController {

    @GetMapping("/api/hola")
    public String hola() {
        return "Backend funcionando correctamente ✔ Recolección de Basura";
    }
}

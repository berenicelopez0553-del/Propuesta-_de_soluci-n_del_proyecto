// js/admin.js
import { Chofer, Colonia, Ruta, Incidencia } from "./models.js";

class AppAdmin {
  constructor() {
    // llaves globales
    this.keyAsignaciones = "asignaciones_camiones";
    this.keyIncidenciasGlobal = "incidencias_global";

    // DOM
    this.tablaAsignaciones = document.getElementById("tablaAsignaciones");
    this.btnCrearAsignacion = document.getElementById("btnCrearAsignacion");
    this.btnGenerarExcel = document.getElementById("btnGenerarExcel");
    this.contenedorAviso = document.getElementById("contAviso");

    // PDF incidencias
    this.listaPDF = document.getElementById("listaPDF");

    // datos cargados
    this.asignaciones = this.cargarAsignaciones() || [];
    this.incidencias = this.cargarIncidenciasGlobal() || [];

    // iniciar
    this.renderTabla();
    this.eventos();
    this.renderPDFs();
  }

  // --------------------------------------
  // STORAGE
  // --------------------------------------

  cargarAsignaciones() {
    try {
      const raw = localStorage.getItem(this.keyAsignaciones);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  guardarAsignaciones() {
    localStorage.setItem(this.keyAsignaciones, JSON.stringify(this.asignaciones));
  }

  cargarIncidenciasGlobal() {
    try {
      const raw = localStorage.getItem(this.keyIncidenciasGlobal);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  guardarIncidenciasGlobal() {
    localStorage.setItem(this.keyIncidenciasGlobal, JSON.stringify(this.incidencias));
  }

  // --------------------------------------
  // TABLA ADMIN (camión–chofer–ayudante–ruta)
  // --------------------------------------

  renderTabla() {
    this.tablaAsignaciones.innerHTML = "";

    this.asignaciones.forEach((a, index) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${a.camion}</td>
        <td>${a.chofer}</td>
        <td>${a.ayudante}</td>
        <td>${a.ruta}</td>
        <td>
          <button class="btnAviso" data-id="${index}">📢 Aviso</button>
          <button class="btnEliminar" data-id="${index}">❌</button>
        </td>
      `;
      this.tablaAsignaciones.appendChild(row);
    });
  }

  // --------------------------------------
  // CREAR ASIGNACIÓN
  // --------------------------------------

  crearAsignacion() {
    const camion = prompt("Número de camión:");
    const chofer = prompt("Nombre del chofer:");
    const ayudante = prompt("Nombre del ayudante:");
    const ruta = prompt("Nombre de la ruta:");

    if (!camion || !chofer || !ayudante || !ruta) {
      alert("Debes completar todos los campos.");
      return;
    }

    const asignacion = { camion, chofer, ayudante, ruta };

    this.asignaciones.push(asignacion);
    this.guardarAsignaciones();
    this.syncConChofer(asignacion);
    this.renderTabla();
  }

  // --------------------------------------
  // SINCRONIZACIÓN CON LOS OPERADORES
  // --------------------------------------

  syncConChofer(asignacion) {
    const keyChofer = `colonias_chofer_${asignacion.chofer}`;
    const keyAyudante = `colonias_chofer_${asignacion.ayudante}`;

    // ejemplo simple: enviar rutas base
    const coloniasAsignadas = [
      { id: 1, nombre: "Colonia Centro", descripcion: "Área principal", estado: "pendiente", locked: false },
      { id: 2, nombre: "Colonia Reforma", descripcion: "Zona residencial", estado: "pendiente", locked: false }
    ];

    localStorage.setItem(keyChofer, JSON.stringify(coloniasAsignadas));
    localStorage.setItem(keyAyudante, JSON.stringify(coloniasAsignadas));
  }

  // --------------------------------------
  // ENVÍO DE AVISO AL OPERADOR
  // --------------------------------------

  enviarAviso(index) {
    const a = this.asignaciones[index];

    const mensaje = prompt(`Escribe el aviso para ${a.chofer}:`);
    if (!mensaje) return;

    const keyAvisoChofer = `aviso_${a.chofer}`;

    localStorage.setItem(keyAvisoChofer, mensaje);

    alert("Aviso enviado al operador.");
  }

  // --------------------------------------
  // generar EXCEL (reporte del día)
  // --------------------------------------

  generarExcel() {
    let csv = "Camión,Chofer,Ayudante,Ruta\n";

    this.asignaciones.forEach(a => {
      csv += `${a.camion},${a.chofer},${a.ayudante},${a.ruta}\n`;
    });

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = "reporte_operacion.csv";
    link.click();
  }

  // --------------------------------------
  // MOSTRAR PDF DE INCIDENCIAS GENERADAS POR EL CHOFER
  // --------------------------------------

  renderPDFs() {
    this.listaPDF.innerHTML = "";

    this.incidencias.forEach(pdf => {
      const item = document.createElement("li");
      item.innerHTML = `<a href="${pdf.url}" target="_blank">${pdf.nombre}</a>`;
      this.listaPDF.appendChild(item);
    });
  }

  // --------------------------------------
  // EVENTOS
  // --------------------------------------

  eventos() {
    // crear asignación
    this.btnCrearAsignacion.addEventListener("click", () => {
      this.crearAsignacion();
    });

    // generar Excel
    this.btnGenerarExcel.addEventListener("click", () => {
      this.generarExcel();
    });

    // botones de aviso y borrar
    this.tablaAsignaciones.addEventListener("click", e => {
      if (e.target.classList.contains("btnAviso")) {
        const id = e.target.dataset.id;
        this.enviarAviso(id);
      }
      if (e.target.classList.contains("btnEliminar")) {
        const id = e.target.dataset.id;
        this.asignaciones.splice(id, 1);
        this.guardarAsignaciones();
        this.renderTabla();
      }
    });
  }
}

// iniciar admin
window.addEventListener("DOMContentLoaded", () => {
  new AppAdmin();
});

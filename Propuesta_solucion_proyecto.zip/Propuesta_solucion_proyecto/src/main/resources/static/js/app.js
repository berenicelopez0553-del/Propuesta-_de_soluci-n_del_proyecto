// js/app.js
import { Chofer, Colonia, Ruta, Incidencia } from "./models.js";

class AppChofer {
  constructor() {
    // chofer simulado (en la realidad vendría del login)
    this.chofer = new Chofer(1, "Juan Pérez", "Unidad 05", "Mañana");

    // claves para localStorage
    this.keyColonias = `colonias_chofer_${this.chofer.id}`;
    this.keyIncidencias = `incidencias_chofer_${this.chofer.id}`;

    // cargar colonias (si admin asignó, vendrán por localStorage; si no, inicializamos vacío)
    this.colonias = this.cargarColonias() || [];

    // si no hay colonias asignadas, dejamos un ejemplo vacío (admin debe asignar)
    if (!this.colonias || this.colonias.length === 0) {
      // no pre-cargamos colonias reales; admin debe asignar
      // pero para pruebas creamos 3 colonias de ejemplo (puedes borrar esto)
      this.colonias = [
        new Colonia(1, "Colonia Centro", "Zona comercial principal"),
        new Colonia(2, "Colonia Hidalgo", "Zona residencial"),
        new Colonia(3, "Colonia Reforma", "Zona habitacional"),
      ];
      this.guardarColonias();
    }

    this.ruta = new Ruta(1, new Date(), this.chofer, this.colonias);
    this.incidencias = this.cargarIncidencias() || [];

    // VISTAS / DOM
    this.infoChofer = document.getElementById("infoChofer");
    this.listaColonias = document.getElementById("listaColonias");

    // vistas
    this.vistaColonias = document.getElementById("vistaColonias");
    this.vistaDetalle = document.getElementById("vistaDetalle");
    this.vistaIncidencia = document.getElementById("vistaIncidencia");

    // detalle
    this.detalleTitulo = document.getElementById("detalleTitulo");
    this.detalleSub = document.getElementById("detalleSub");
    this.detalleDescripcion = document.getElementById("detalleDescripcion");
    this.detalleEstadoBadge = document.getElementById("detalleEstadoBadge");
    this.detalleMensaje = document.getElementById("detalleMensaje");
    this.btnIniciarRuta = document.getElementById("btnIniciarRuta");
    this.btnFinalizarRuta = document.getElementById("btnFinalizarRuta");
    this.btnAbrirIncidenciaDetalle = document.getElementById("btnAbrirIncidenciaDetalle");
    this.btnVolverLista = document.getElementById("btnVolverLista");

    // incidencia
    this.opcionesIncidencia = document.getElementById("opcionesIncidencia");
    this.previewMsg = document.getElementById("previewMsg");
    this.btnAbrirCam = document.getElementById("btnAbrirCam");
    this.btnCapturar = document.getElementById("btnCapturar");
    this.btnEliminarFoto = document.getElementById("btnEliminarFoto");
    this.video = document.getElementById("video");
    this.canvas = document.getElementById("canvas");
    this.btnEnviarReporte = document.getElementById("btnEnviarReporte");
    this.btnCancelarReporte = document.getElementById("btnCancelarReporte");
    this.btnVolverDetalle = document.getElementById("btnVolverDetalle");

    // estado interno
    this.coloniaActiva = null;
    this.incidenciaTipoSeleccionada = null;
    this.fotoDataUrl = null;
    this.mediaStream = null;

    // arrancar
    this.iniciar();
  }

  iniciar() {
    this.mostrarInfoChofer();
    this.mostrarColonias();
    this.configurarEventos();
    this.configurarIncidenciaEventos();
  }

  // --- storage ---
  cargarColonias() {
    try {
      const raw = localStorage.getItem(this.keyColonias);
      if (!raw) return null;
      const arr = JSON.parse(raw);
      // reconstruir Colonia objects
      return arr.map(x => {
        const c = new Colonia(x.id, x.nombre, x.descripcion);
        c.estado = x.estado || "pendiente";
        c.locked = !!x.locked;
        return c;
      });
    } catch (e) {
      console.error("Error cargando colonias:", e);
      return null;
    }
  }

  guardarColonias() {
    localStorage.setItem(this.keyColonias, JSON.stringify(this.colonias));
  }

  cargarIncidencias() {
    try {
      const raw = localStorage.getItem(this.keyIncidencias);
      if (!raw) return [];
      return JSON.parse(raw);
    } catch (e) {
      console.error("Error cargando incidencias:", e);
      return [];
    }
  }

  guardarIncidencias() {
    localStorage.setItem(this.keyIncidencias, JSON.stringify(this.incidencias));
  }

  // --- UI ---
  mostrarInfoChofer() {
    const c = this.chofer;
    this.infoChofer.innerHTML = `
      <div><strong>Chofer:</strong> ${c.nombre}</div>
      <div><strong>Camión:</strong> ${c.camion}</div>
      <div><strong>Turno:</strong> ${c.turno}</div>
    `;
  }

  mostrarColonias() {
    this.listaColonias.innerHTML = "";
    this.colonias.forEach(colonia => {
      const card = document.createElement("article");
      card.className = "colonia-card";
      card.dataset.id = colonia.id;

      // estado texto
      let estadoText = this.traducirEstado(colonia.estado);
      card.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div>
            <div class="colonia-titulo">${colonia.nombre}</div>
            <div class="colonia-detalle">${colonia.descripcion}</div>
            <div class="colonia-estado">Estado: ${estadoText}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-end;">
            <button class="btn-siguiente">${colonia.locked ? "🔒 Bloqueada" : "▶ Siguiente"}</button>
            <div style="font-size:12px;color:#6b7280;margin-top:4px;">ID: ${colonia.id}</div>
          </div>
        </div>
        <div class="mensaje"></div>
      `;

      const btnNext = card.querySelector(".btn-siguiente");
      const mensaje = card.querySelector(".mensaje");

      if (colonia.locked) btnNext.classList.add("disabled");

      btnNext.addEventListener("click", () => {
        if (colonia.locked) {
          mensaje.textContent = "Esta colonia está bloqueada. Solicita al administrador desbloquearla.";
          return;
        }
        this.abrirDetalle(colonia.id);
      });

      this.listaColonias.appendChild(card);
    });
  }

  traducirEstado(estado) {
    if (estado === "atendida") return "Atendida";
    if (estado === "no_atendido") return "No atendida";
    if (estado === "en_proceso") return "En proceso";
    if (estado === "incompleta") return "Incompleta";
    return "Pendiente";
  }

  // --- vistas navigation ---
  mostrarVista(vista) {
    this.vistaColonias.classList.add("hidden");
    this.vistaDetalle.classList.add("hidden");
    this.vistaIncidencia.classList.add("hidden");

    if (vista === "colonias") this.vistaColonias.classList.remove("hidden");
    if (vista === "detalle") this.vistaDetalle.classList.remove("hidden");
    if (vista === "incidencia") this.vistaIncidencia.classList.remove("hidden");
  }

  abrirDetalle(coloniaId) {
    const c = this.colonias.find(x => x.id == coloniaId);
    if (!c) return;
    this.coloniaActiva = c;
    this.detalleTitulo.textContent = c.nombre;
    this.detalleSub.textContent = `ID: ${c.id}`;
    this.detalleDescripcion.textContent = c.descripcion;
    this.detalleMensaje.textContent = "";
    this.actualizarEstadoDetalle();
    this.mostrarVista("detalle");
  }

  volverLista() {
    this.coloniaActiva = null;
    this.mostrarVista("colonias");
    this.mostrarColonias();
  }

  // actualizar badge estado con clases de color
  actualizarEstadoDetalle() {
    const c = this.coloniaActiva;
    this.detalleEstadoBadge.className = "estado-badge";
    if (c.estado === "en_proceso") {
      this.detalleEstadoBadge.classList.add("estado-enproceso");
      this.detalleEstadoBadge.textContent = "En proceso";
    } else if (c.estado === "atendida") {
      this.detalleEstadoBadge.classList.add("estado-atendida");
      this.detalleEstadoBadge.textContent = "Atendida";
    } else if (c.estado === "incompleta") {
      this.detalleEstadoBadge.classList.add("estado-incompleta");
      this.detalleEstadoBadge.textContent = "Incompleta";
    } else {
      this.detalleEstadoBadge.classList.add("estado-pendiente");
      this.detalleEstadoBadge.textContent = "No atendido";
    }

    // controles segun estado/locked
    if (c.locked) {
      this.detalleMensaje.textContent = "Colonia bloqueada. No se pueden realizar acciones hasta que el administrador la desbloquee.";
      this.btnIniciarRuta.classList.add("disabled");
      this.btnFinalizarRuta.classList.add("disabled");
      this.btnAbrirIncidenciaDetalle.classList.add("disabled");
    } else {
      this.detalleMensaje.textContent = "";
      if (c.estado === "en_proceso") {
        this.btnIniciarRuta.classList.add("disabled");
        this.btnFinalizarRuta.classList.remove("disabled");
        this.btnAbrirIncidenciaDetalle.classList.remove("disabled");
      } else if (c.estado === "atendida" || c.estado === "incompleta") {
        // no permitir acciones
        this.btnIniciarRuta.classList.add("disabled");
        this.btnFinalizarRuta.classList.add("disabled");
        this.btnAbrirIncidenciaDetalle.classList.add("disabled");
      } else {
        // pendiente/no_atendido
        this.btnIniciarRuta.classList.remove("disabled");
        this.btnFinalizarRuta.classList.add("disabled");
        this.btnAbrirIncidenciaDetalle.classList.remove("disabled");
      }
    }
  }

  // --- eventos detalle e inicio/fin ---
  configurarEventos() {
    this.btnVolverLista.addEventListener("click", () => this.volverLista());

    this.btnIniciarRuta.addEventListener("click", () => {
      if (!this.coloniaActiva) return;
      if (this.coloniaActiva.locked) {
        this.detalleMensaje.textContent = "No puedes iniciar: colonia bloqueada.";
        return;
      }
      this.coloniaActiva.estado = "en_proceso";
      this.guardarColonias();
      this.actualizarEstadoDetalle();
      this.mostrarColonias();
    });

    this.btnFinalizarRuta.addEventListener("click", () => {
      if (!this.coloniaActiva) return;
      if (this.coloniaActiva.estado !== "en_proceso") {
        this.detalleMensaje.textContent = "Debes iniciar la ruta antes de finalizarla.";
        return;
      }
      this.coloniaActiva.estado = "atendida";
      this.coloniaActiva.locked = true; // bloquear hasta admin desbloquee
      this.guardarColonias();
      this.actualizarEstadoDetalle();
      this.mostrarColonias();
      // impedir reabrir automáticamente
    });

    this.btnAbrirIncidenciaDetalle.addEventListener("click", () => {
      if (!this.coloniaActiva) return;
      if (this.coloniaActiva.locked) {
        this.detalleMensaje.textContent = "No puedes reportar: colonia bloqueada.";
        return;
      }
      // abrir vista de incidencia
      this.openIncidenciaView();
    });

    // volver desde incidencia a detalle
    if (this.btnVolverDetalle) {
      this.btnVolverDetalle.addEventListener("click", () => {
        this.mostrarVista("detalle");
      });
    }
  }

  // --- INCIDENCIAS (vista interna) ---
  configureIncidenceDOM() {
    // helper: returns node list of buttons
    return this.opcionesIncidencia.querySelectorAll("button");
  }

  configurarIncidenciaEventos() {
    // tipo select
    this.configureIncidenceDOM().forEach(btn => {
      btn.addEventListener("click", () => {
        this.configureIncidenceDOM().forEach(b => b.style.borderColor = "#e5e7eb");
        btn.style.borderColor = "#0ea5e9";
        this.incidenciaTipoSeleccionada = btn.dataset.tipo;
        this.previewMsg.textContent = `Seleccionada: ${this.incidenciaTipoSeleccionada}`;
      });
    });

    // cámara
    this.btnAbrirCam.addEventListener("click", async () => {
      await this.startCamera();
      this.video.style.display = "block";
      this.btnCapturar.classList.remove("disabled");
      this.previewMsg.textContent = "Apunta y presiona Capturar.";
    });

    this.btnCapturar.addEventListener("click", () => {
      if (!this.mediaStream) return;
      const w = this.video.videoWidth;
      const h = this.video.videoHeight;
      this.canvas.width = w;
      this.canvas.height = h;
      const ctx = this.canvas.getContext("2d");
      ctx.drawImage(this.video, 0, 0, w, h);
      this.fotoDataUrl = this.canvas.toDataURL("image/png");
      this.canvas.style.display = "block";
      this.video.style.display = "none";
      this.btnEliminarFoto.classList.remove("disabled");
      this.previewMsg.textContent = "Foto tomada.";
      this.stopCamera();
      this.btnCapturar.classList.add("disabled");
    });

    this.btnEliminarFoto.addEventListener("click", () => {
      this.fotoDataUrl = null;
      this.canvas.style.display = "none";
      this.video.style.display = "none";
      this.btnEliminarFoto.classList.add("disabled");
      this.btnCapturar.classList.add("disabled");
      this.previewMsg.textContent = "Foto eliminada.";
      this.stopCamera();
    });

    this.btnEnviarReporte.addEventListener("click", () => {
      if (!this.incidenciaTipoSeleccionada) {
        this.previewMsg.textContent = "Selecciona primero el tipo de incidencia.";
        return;
      }
      if (!this.coloniaActiva) {
        this.previewMsg.textContent = "Error: colonia no seleccionada.";
        return;
      }

      // crear incidencia
      const inc = new Incidencia(
        Date.now(),
        this.incidenciaTipoSeleccionada,
        this.fotoDataUrl || null,
        new Date(),
        this.ruta.id,
        this.coloniaActiva.id
      );

      this.incidencias.push(inc);
      this.guardarIncidencias();

      // cambiar estado y bloquear colonia
      this.coloniaActiva.estado = "incompleta";
      this.coloniaActiva.locked = true;
      this.guardarColonias();

      this.previewMsg.textContent = "Incidencia enviada. Colonia marcada como INCOMPLETA y bloqueada.";
      // volver a detalle (se refresca)
      setTimeout(() => {
        this.fotoDataUrl = null;
        this.incidenciaTipoSeleccionada = null;
        // reset visual
        this.configureIncidenceDOM().forEach(b => b.style.borderColor = "#e5e7eb");
        this.mostrarVista("detalle");
        this.actualizarEstadoDetalle();
        this.mostrarColonias();
      }, 800);
    });

    this.btnCancelarReporte.addEventListener("click", () => {
      // limpiar y volver
      this.fotoDataUrl = null;
      this.incidenciaTipoSeleccionada = null;
      this.configureIncidenceDOM().forEach(b => b.style.borderColor = "#e5e7eb");
      this.stopCamera();
      this.mostrarVista("detalle");
    });
  }

  openIncidenciaView() {
    // reset
    this.incidenciaTipoSeleccionada = null;
    this.fotoDataUrl = null;
    this.canvas.style.display = "none";
    this.video.style.display = "none";
    this.btnCapturar.classList.add("disabled");
    this.btnEliminarFoto.classList.add("disabled");
    this.configureIncidenceDOM().forEach(b => b.style.borderColor = "#e5e7eb");
    this.previewMsg.textContent = "Selecciona el tipo de incidencia.";
    this.mostrarVista("incidencia");
  }

  // cámara helpers
  async startCamera() {
    if (this.mediaStream) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      this.mediaStream = stream;
      this.video.srcObject = stream;
      await this.video.play();
    } catch (err) {
      console.error("No se pudo abrir la cámara:", err);
      this.previewMsg.textContent = "No se pudo acceder a la cámara (ver permisos).";
    }
  }

  stopCamera() {
    if (!this.mediaStream) return;
    this.mediaStream.getTracks().forEach(t => t.stop());
    this.mediaStream = null;
    if (this.video) this.video.srcObject = null;
  }
}

// iniciar app
window.addEventListener("DOMContentLoaded", () => {
  const app = new AppChofer();
  // configurar eventos de incidencia (después de creada la app)
  app.configurarIncidenciaEventos();
});

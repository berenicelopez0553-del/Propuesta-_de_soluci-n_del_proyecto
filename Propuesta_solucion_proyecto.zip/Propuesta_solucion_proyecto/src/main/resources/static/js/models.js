// js/models.js
export class Chofer {
  constructor(id, nombre, camion, turno) {
    this.id = id;
    this.nombre = nombre;
    this.camion = camion;
    this.turno = turno;
  }
}

export class Colonia {
  constructor(id, nombre, descripcion) {
    this.id = id;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.estado = "no_atendido"; // no_atendido | en_proceso | atendida | incompleta
    this.locked = false; // temporal (no usado para bloquear por admin en pruebas)
  }
}

export class Ruta {
  constructor(id, fecha, chofer, colonias = []) {
    this.id = id;
    this.fecha = fecha;
    this.chofer = chofer;
    this.colonias = colonias;
  }
}

export class Incidencia {
  constructor(id, tipo, fotoDataUrl, fecha, rutaId, coloniaId) {
    this.id = id;
    this.tipo = tipo;
    this.foto = fotoDataUrl || null;
    this.fecha = fecha;
    this.rutaId = rutaId;
    this.coloniaId = coloniaId;
  }
}

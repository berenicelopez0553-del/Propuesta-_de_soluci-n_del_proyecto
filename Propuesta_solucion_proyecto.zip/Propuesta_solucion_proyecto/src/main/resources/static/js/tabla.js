// ===============================
//  Obtener elementos del DOM
// ===============================
const selectCamion = document.getElementById("selectCamion");
const selectChofer = document.getElementById("selectChofer");
const selectAyudante = document.getElementById("selectAyudante");
const selectColonias = document.getElementById("selectColonias");

const btnAsignarRuta = document.getElementById("btnAsignarRuta");
const btnEnviarAviso = document.getElementById("btnEnviarAviso");
const btnGenerarExcel = document.getElementById("btnGenerarExcel");
const btnFinalizarJornada = document.getElementById("btnFinalizarJornada");

const resumenDia = document.getElementById("resumenDia");
const listaColonias = document.getElementById("listaColonias");
const listaIncidencias = document.getElementById("listaIncidencias");
const visorPDF = document.getElementById("visorPDF");

// ========================================
//   ASIGNAR RUTA A OPERADORES
// ========================================
btnAsignarRuta.addEventListener("click", () => {
  const camion = selectCamion.value;
  const chofer = selectChofer.value;
  const ayudante = selectAyudante.value;

  const colonias = Array.from(selectColonias.selectedOptions).map(c => c.value);

  if (!camion || !chofer || colonias.length === 0) {
    alert("Por favor complete todos los campos.");
    return;
  }

  const ruta = {
    camion,
    chofer,
    ayudante,
    colonias,
    fecha: new Date().toLocaleDateString()
  };

  localStorage.setItem("rutaAsignada", JSON.stringify(ruta));

  alert("✔ Ruta asignada correctamente");

  mostrarColonias();
  mostrarResumen();
});

// ========================================
//   ENVIAR AVISO AL OPERADOR
// ========================================
btnEnviarAviso.addEventListener("click", () => {
  const mensaje = document.getElementById("mensajeAviso").value;

  if (!mensaje.trim()) {
    alert("Escribe un mensaje.");
    return;
  }

  localStorage.setItem("avisoChofer", mensaje);

  alert("✔ Aviso enviado al chofer y ayudante");
});

// ========================================
//   MOSTRAR COLONIAS ASIGNADAS
// ========================================
function mostrarColonias() {
  const ruta = JSON.parse(localStorage.getItem("rutaAsignada"));

  if (!ruta) {
    listaColonias.innerHTML = "<p>No hay rutas asignadas aún.</p>";
    return;
  }

  listaColonias.innerHTML = `
    <ul>
      ${ruta.colonias.map(c => `<li>${c}</li>`).join("")}
    </ul>
  `;
}

// ========================================
//   MOSTRAR RESUMEN DEL DÍA
// ========================================
function mostrarResumen() {
  const ruta = JSON.parse(localStorage.getItem("rutaAsignada"));

  if (!ruta) {
    resumenDia.innerHTML = "<p>No hay datos aún.</p>";
    return;
  }

  resumenDia.innerHTML = `
    <p><strong>Camión:</strong> ${ruta.camion}</p>
    <p><strong>Chofer:</strong> ${ruta.chofer}</p>
    <p><strong>Ayudante:</strong> ${ruta.ayudante}</p>
    <p><strong>Colonias:</strong> ${ruta.colonias.join(", ")}</p>
    <p><strong>Fecha:</strong> ${ruta.fecha}</p>
  `;
}

// ========================================
//     MOSTRAR INCIDENCIAS Y PDF
// ========================================
function mostrarIncidencias() {
  const incidencias = JSON.parse(localStorage.getItem("incidencias")) || [];
  const pdf = localStorage.getItem("pdfIncidencias");

  if (incidencias.length === 0) {
    listaIncidencias.innerHTML = "<p>No hay incidencias registradas.</p>";
  } else {
    listaIncidencias.innerHTML = `
      <ul>
        ${incidencias.map(i => `<li>${i.tipo} - ${i.detalle}</li>`).join("")}
      </ul>
    `;
  }

  if (pdf) {
    visorPDF.src = pdf;
  }
}

// ========================================
//     GENERAR EXCEL DEL DÍA
// ========================================
btnGenerarExcel.addEventListener("click", () => {
  const ruta = JSON.parse(localStorage.getItem("rutaAsignada"));

  if (!ruta) {
    alert("No hay datos para generar el reporte.");
    return;
  }

  let contenido = `
Camión: ${ruta.camion}
Chofer: ${ruta.chofer}
Ayudante: ${ruta.ayudante}
Colonias: ${ruta.colonias.join(", ")}
Fecha: ${ruta.fecha}
  `;

  const blob = new Blob([contenido], { type: "application/vnd.ms-excel" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "Reporte_Diario.xls";
  a.click();

  URL.revokeObjectURL(url);
});

// ========================================
//     FINALIZAR JORNADA
// ========================================
btnFinalizarJornada.addEventListener("click", () => {
  if (confirm("¿Seguro que deseas finalizar la jornada?")) {
    localStorage.clear();
    alert("Jornada finalizada.");
    location.reload();
  }
});

// ARRANQUE AUTOMÁTICO
mostrarColonias();
mostrarResumen();
mostrarIncidencias();

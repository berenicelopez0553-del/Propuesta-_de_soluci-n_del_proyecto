// ====== Datos del camión (simulados; normalmente vendrían del backend) ======
const camion = {
  name: "Camión 102",
  plate: "ABC-123",
  driverName: "Juan Pérez",
  helperName: "Luis Gómez",
  schedule: "Matutino 07:00 - 15:00",
  assignedRoutesText: "Ruta 101 - Centro, Ruta 202 - Norte, Ruta 303 - Sur"
};

// Rutas del camión
let routes = [
  { id: 1, name: "Ruta 101 - Centro", status: "no_iniciado", locked: false, startTime: null, endTime: null },
  { id: 2, name: "Ruta 202 - Norte", status: "no_iniciado", locked: false, startTime: null, endTime: null },
  { id: 3, name: "Ruta 303 - Sur", status: "no_iniciado", locked: false, startTime: null, endTime: null }
];

let currentRouteId = null;

// Incidencia actual
let selectedIncidenceType = null;
let selectedPhotoFile = null;

// ====== Referencias de UI ======
const truckNameSpan = document.getElementById("truckName");
const truckPlateSpan = document.getElementById("truckPlate");
const driverNameSpan = document.getElementById("driverName");
const helperNameSpan = document.getElementById("helperName");
const truckScheduleSpan = document.getElementById("truckSchedule");
const assignedRoutesTextSpan = document.getElementById("assignedRoutesText");

const screenMain = document.getElementById("screen-main");
const screenRoute = document.getElementById("screen-route");
const screenIncidence = document.getElementById("screen-incidence");

const routesContainer = document.getElementById("routesContainer");

const routeDetailName = document.getElementById("routeDetailName");
const routeDetailStatus = document.getElementById("routeDetailStatus");
const routeDetailStart = document.getElementById("routeDetailStart");
const routeDetailEnd = document.getElementById("routeDetailEnd");

const btnFinishWork = document.getElementById("btnFinishWork");
const btnStartRoute = document.getElementById("btnStartRoute");
const btnEndRoute = document.getElementById("btnEndRoute");
const btnIncidenceReport = document.getElementById("btnIncidenceReport");
const btnBackMain = document.getElementById("btnBackMain");

const incidenceRouteName = document.getElementById("incidenceRouteName");
const incidenceTypeButtons = document.querySelectorAll(".btn-toggle");
const btnTakePhotoCamera = document.getElementById("btnTakePhotoCamera");
const btnPickFromGallery = document.getElementById("btnPickFromGallery");
const photoInputCamera = document.getElementById("photoInputCamera");
const photoInputGallery = document.getElementById("photoInputGallery");
const photoInfo = document.getElementById("photoInfo");
const btnSendReport = document.getElementById("btnSendReport");
const btnCancelIncidence = document.getElementById("btnCancelIncidence");

const notificationBanner = document.getElementById("notificationBanner");

// ====== Funciones utilitarias ======
function showScreen(name) {
  screenMain.classList.remove("active");
  screenRoute.classList.remove("active");
  screenIncidence.classList.remove("active");

  if (name === "main") screenMain.classList.add("active");
  if (name === "route") screenRoute.classList.add("active");
  if (name === "incidence") screenIncidence.classList.add("active");
}

function getStatusLabel(status) {
  return {
    no_iniciado: "No iniciado",
    en_proceso: "En proceso",
    finalizado: "Finalizado",
    incompleto: "Incompleto (incidencia)"
  }[status] || status;
}

function nowTimeString() {
  const d = new Date();
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const ss = String(d.getSeconds()).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

function updateFinishWorkButton() {
  const allClosed = routes.every(r =>
    r.status === "finalizado" || r.status === "incompleto"
  );
  btnFinishWork.disabled = !allClosed;
}

function renderHeader() {
  truckNameSpan.textContent = camion.name;
  truckPlateSpan.textContent = camion.plate;
  driverNameSpan.textContent = camion.driverName;
  helperNameSpan.textContent = camion.helperName;
  truckScheduleSpan.textContent = camion.schedule;
  assignedRoutesTextSpan.textContent = camion.assignedRoutesText;
}

function renderRoutesList() {
  routesContainer.innerHTML = "";
  routes.forEach(route => {
    const card = document.createElement("div");
    card.className = "card";

    const title = document.createElement("h3");
    title.textContent = route.name;

    const status = document.createElement("span");
    status.className = `status-pill status-${route.status}`;
    status.textContent = getStatusLabel(route.status);

    const statusLine = document.createElement("p");
    statusLine.innerHTML = "Estado: ";
    statusLine.appendChild(status);

    const timeLine = document.createElement("p");
    timeLine.innerHTML =
      `<strong>Inicio:</strong> ${route.startTime || "-"} &nbsp; <strong>Fin:</strong> ${route.endTime || "-"}`;

    const lockedText = document.createElement("p");
    lockedText.className = "info-text";
    if (route.locked) {
      lockedText.textContent = "Ruta bloqueada. Esperando habilitación del administrador.";
    }

    const btn = document.createElement("button");
    btn.className = "btn btn-primary";
    btn.textContent = "Ver / Siguiente";
    btn.onclick = () => openRouteDetail(route.id);

    card.appendChild(title);
    card.appendChild(statusLine);
    card.appendChild(timeLine);
    if (lockedText.textContent) card.appendChild(lockedText);
    card.appendChild(btn);

    routesContainer.appendChild(card);
  });

  updateFinishWorkButton();
}

function renderRouteDetail() {
  const route = routes.find(r => r.id === currentRouteId);
  if (!route) return;

  routeDetailName.textContent = route.name;
  routeDetailStatus.textContent = getStatusLabel(route.status);
  routeDetailStatus.className = "status-pill status-" + route.status;
  routeDetailStart.textContent = route.startTime || "-";
  routeDetailEnd.textContent = route.endTime || "-";

  const isLocked = route.locked;
  const status = route.status;

  btnStartRoute.disabled = !(status === "no_iniciado" && !isLocked);
  btnEndRoute.disabled = !(status === "en_proceso" && !isLocked);
  btnIncidenceReport.disabled = isLocked;
}

function openRouteDetail(routeId) {
  currentRouteId = routeId;
  renderRouteDetail();
  showScreen("route");
}

// ====== Eventos de botones en pantalla de ruta ======
btnStartRoute.addEventListener("click", () => {
  const route = routes.find(r => r.id === currentRouteId);
  if (!route || route.locked) return;

  route.status = "en_proceso";
  if (!route.startTime) {
    route.startTime = nowTimeString();
  }

  // Aquí podrías notificar al backend que empezó la ruta

  renderRouteDetail();
  renderRoutesList();
});

btnEndRoute.addEventListener("click", () => {
  const route = routes.find(r => r.id === currentRouteId);
  if (!route || route.locked) return;
  if (route.status !== "en_proceso") return;

  route.status = "finalizado";
  route.endTime = nowTimeString();
  route.locked = true; // Bloqueamos hasta que el admin habilite de nuevo

  // Aquí podrías enviar al backend startTime/endTime + estado finalizado.

  renderRouteDetail();
  renderRoutesList();
  showScreen("main");
});

btnIncidenceReport.addEventListener("click", () => {
  const route = routes.find(r => r.id === currentRouteId);
  if (!route || route.locked) return;

  route.status = "incompleto";
  renderRoutesList();

  selectedIncidenceType = null;
  selectedPhotoFile = null;
  incidenceRouteName.textContent = route.name;
  incidenceTypeButtons.forEach(btn => btn.classList.remove("selected"));

  btnTakePhotoCamera.disabled = true;
  btnPickFromGallery.disabled = true;
  btnSendReport.disabled = true;
  photoInfo.textContent = "";

  showScreen("incidence");
});

btnBackMain.addEventListener("click", () => {
  showScreen("main");
});

// ====== Incidencias ======
incidenceTypeButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    incidenceTypeButtons.forEach(b => b.classList.remove("selected"));
    btn.classList.add("selected");
    selectedIncidenceType = btn.getAttribute("data-type");
    // Una vez seleccionado tipo, habilitamos opciones de foto
    btnTakePhotoCamera.disabled = false;
    btnPickFromGallery.disabled = false;
  });
});

// Cámara
btnTakePhotoCamera.addEventListener("click", () => {
  photoInputCamera.click();
});

photoInputCamera.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) {
    selectedPhotoFile = file;
    photoInfo.textContent = "Foto seleccionada desde cámara: " + file.name;
    btnSendReport.disabled = false;
  }
});

// Galería
btnPickFromGallery.addEventListener("click", () => {
  photoInputGallery.click();
});

photoInputGallery.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) {
    selectedPhotoFile = file;
    photoInfo.textContent = "Imagen seleccionada desde galería: " + file.name;
    btnSendReport.disabled = false;
  }
});

btnSendReport.addEventListener("click", () => {
  if (!selectedIncidenceType || !selectedPhotoFile) return;

  const route = routes.find(r => r.id === currentRouteId);
  if (!route) return;

  route.endTime = nowTimeString();
  route.locked = true;

  // Aquí podrías enviar al backend:
  // - datos de la incidencia
  // - archivo de foto
  // - estado de la ruta (incompleto) con startTime/endTime
  alert(
    "Reporte de incidencia enviado.\nTipo: " +
    selectedIncidenceType +
    "\nLa ruta ha quedado bloqueada hasta que el administrador la habilite."
  );

  renderRoutesList();
  showScreen("main");
});

btnCancelIncidence.addEventListener("click", () => {
  showScreen("route");
});

// ====== Finalizar labores ======
btnFinishWork.addEventListener("click", () => {
  const confirmExit = confirm(
    "Todas las rutas están cerradas.\n¿Deseas finalizar labores y volver a la pantalla de login?"
  );
  if (!confirmExit) return;

  alert("Sesión del camión finalizada. Redirigiendo a pantalla de login...");
  // window.location.href = "login.html";
});

// ====== Notificaciones desde el administrador ======
function mostrarNotificacion(mensaje) {
  notificationBanner.textContent = "Mensaje del administrador: " + mensaje;
  notificationBanner.style.display = "block";

  alert("Mensaje del administrador:\n" + mensaje);

  setTimeout(() => {
    notificationBanner.style.display = "none";
  }, 5000);
}

// Función global para que otra parte del sistema pueda llamar
// window.recibirNotificacion("texto");
window.recibirNotificacion = function(mensaje) {
  mostrarNotificacion(mensaje);
};

// ====== Inicialización ======
function init() {
  renderHeader();
  renderRoutesList();
}

init();

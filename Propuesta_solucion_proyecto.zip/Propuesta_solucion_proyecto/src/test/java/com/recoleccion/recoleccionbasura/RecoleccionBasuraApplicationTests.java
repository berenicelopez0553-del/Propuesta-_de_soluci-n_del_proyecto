package com.recoleccion.recoleccionbasura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecoleccionBasuraApplicationTests {

	@Test
	void contextLoads() {
	}

}
